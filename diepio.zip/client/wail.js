const SECTION_CUSTOM = 0,
    SECTION_TYPE = 1,
    SECTION_IMPORT = 2,
    SECTION_FUNCTION = 3,
    SECTION_TABLE = 4,
    SECTION_MEMORY = 5,
    SECTION_GLOBAL = 6,
    SECTION_EXPORT = 7,
    SECTION_START = 8,
    SECTION_ELEMENT = 9,
    SECTION_CODE = 10,
    SECTION_DATA = 11,
    SECTION_DATACOUNT = 12,
    MAX_SECTION_ID = 12,
    KIND_FUNC = 0,
    KIND_TABLE = 1,
    KIND_MEMORY = 2,
    KIND_GLOBAL = 3,
    kindStr = {
        func: KIND_FUNC,
        table: KIND_TABLE,
        memory: KIND_MEMORY,
        global: KIND_GLOBAL
    },
    convertKind = function(e) {
        const t = kindStr[e];
        if (void 0 === t) throw new Error("Invalid kind " + e);
        return t
    },
    VALUE_TYPE_I32 = 127,
    VALUE_TYPE_I64 = 126,
    VALUE_TYPE_F32 = 125,
    VALUE_TYPE_F64 = 124,
    VALUE_TYPE_ANYFUNC = 112,
    VALUE_TYPE_FUNC = 96,
    VALUE_TYPE_BLOCK = 64,
    valueTypeStr = {
        i32: 127,
        i64: 126,
        f32: 125,
        f64: 124,
        anyfunc: 112,
        func: 96,
        block: 64
    },
    convertValueType = function(e) {
        const t = valueTypeStr[e];
        if (void 0 === t) throw new Error("Invalid value type " + e);
        return t
    },
    OP_UNREACHABLE = 0,
    OP_NOP = 1,
    OP_BLOCK = 2,
    OP_LOOP = 3,
    OP_IF = 4,
    OP_ELSE = 5,
    OP_END = 11,
    OP_BR = 12,
    OP_BR_IF = 13,
    OP_BR_TABLE = 14,
    OP_RETURN = 15,
    OP_CALL = 16,
    OP_CALL_INDIRECT = 17,
    OP_DROP = 26,
    OP_SELECT = 27,
    OP_GET_LOCAL = 32,
    OP_SET_LOCAL = 33,
    OP_TEE_LOCAL = 34,
    OP_GET_GLOBAL = 35,
    OP_SET_GLOBAL = 36,
    OP_I32_LOAD = 40,
    OP_I64_LOAD = 41,
    OP_F32_LOAD = 42,
    OP_F64_LOAD = 43,
    OP_I32_LOAD8_S = 44,
    OP_I32_LOAD8_U = 45,
    OP_I32_LOAD16_S = 46,
    OP_I32_LOAD16_U = 47,
    OP_I64_LOAD8_S = 48,
    OP_I64_LOAD8_U = 49,
    OP_I64_LOAD16_S = 50,
    OP_I64_LOAD16_U = 51,
    OP_I64_LOAD32_S = 52,
    OP_I64_LOAD32_U = 53,
    OP_I32_STORE = 54,
    OP_I64_STORE = 55,
    OP_F32_STORE = 56,
    OP_F64_STORE = 57,
    OP_I32_STORE8 = 58,
    OP_I32_STORE16 = 59,
    OP_I64_STORE8 = 60,
    OP_I64_STORE16 = 61,
    OP_I64_STORE32 = 62,
    OP_MEMORY_SIZE = 63,
    OP_MEMORY_GROW = 64,
    OP_I32_CONST = 65,
    OP_I64_CONST = 66,
    OP_F32_CONST = 67,
    OP_F64_CONST = 68,
    OP_I32_EQZ = 69,
    OP_I32_EQ = 70,
    OP_I32_NE = 71,
    OP_I32_LT_S = 72,
    OP_I32_LT_U = 73,
    OP_I32_GT_S = 74,
    OP_I32_GT_U = 75,
    OP_I32_LE_S = 76,
    OP_I32_LE_U = 77,
    OP_I32_GE_S = 78,
    OP_I32_GE_U = 79,
    OP_I64_EQZ = 80,
    OP_I64_EQ = 81,
    OP_I64_NE = 82,
    OP_I64_LT_S = 83,
    OP_I64_LT_U = 84,
    OP_I64_GT_S = 85,
    OP_I64_GT_U = 86,
    OP_I64_LE_S = 87,
    OP_I64_LE_U = 88,
    OP_I64_GE_S = 89,
    OP_I64_GE_U = 90,
    OP_F32_EQ = 91,
    OP_F32_NE = 92,
    OP_F32_LT = 93,
    OP_F32_GT = 94,
    OP_F32_LE = 95,
    OP_F32_GE = 96,
    OP_F64_EQ = 97,
    OP_F64_NE = 98,
    OP_F64_LT = 99,
    OP_F64_GT = 100,
    OP_F64_LE = 101,
    OP_F64_GE = 102,
    OP_I32_CLZ = 103,
    OP_I32_CTZ = 104,
    OP_I32_POPCNT = 105,
    OP_I32_ADD = 106,
    OP_I32_SUB = 107,
    OP_I32_MUL = 108,
    OP_I32_DIV_S = 109,
    OP_I32_DIV_U = 110,
    OP_I32_REM_S = 111,
    OP_I32_REM_U = 112,
    OP_I32_AND = 113,
    OP_I32_OR = 114,
    OP_I32_XOR = 115,
    OP_I32_SHL = 116,
    OP_I32_SHR_S = 117,
    OP_I32_SHR_U = 118,
    OP_I32_ROTL = 119,
    OP_I32_ROTR = 120,
    OP_I64_CLZ = 121,
    OP_I64_CTZ = 122,
    OP_I64_POPCNT = 123,
    OP_I64_ADD = 124,
    OP_I64_SUB = 125,
    OP_I64_MUL = 126,
    OP_I64_DIV_S = 127,
    OP_I64_DIV_U = 128,
    OP_I64_REM_S = 129,
    OP_I64_REM_U = 130,
    OP_I64_AND = 131,
    OP_I64_OR = 132,
    OP_I64_XOR = 133,
    OP_I64_SHL = 134,
    OP_I64_SHR_S = 135,
    OP_I64_SHR_U = 136,
    OP_I64_ROTL = 137,
    OP_I64_ROTR = 138,
    OP_F32_ABS = 139,
    OP_F32_NEG = 140,
    OP_F32_CEIL = 141,
    OP_F32_FLOOR = 142,
    OP_F32_TRUNC = 143,
    OP_F32_NEAREST = 144,
    OP_F32_SQRT = 145,
    OP_F32_ADD = 146,
    OP_F32_SUB = 147,
    OP_F32_MUL = 148,
    OP_F32_DIV = 149,
    OP_F32_MIN = 150,
    OP_F32_MAX = 151,
    OP_F32_COPYSIGN = 152,
    OP_F64_ABS = 153,
    OP_F64_NEG = 154,
    OP_F64_CEIL = 155,
    OP_F64_FLOOR = 156,
    OP_F64_TRUNC = 157,
    OP_F64_NEAREST = 158,
    OP_F64_SQRT = 159,
    OP_F64_ADD = 160,
    OP_F64_SUB = 161,
    OP_F64_MUL = 162,
    OP_F64_DIV = 163,
    OP_F64_MIN = 164,
    OP_F64_MAX = 165,
    OP_F64_COPYSIGN = 166,
    OP_I32_WRAP_I64 = 167,
    OP_I32_TRUNC_S_F32 = 168,
    OP_I32_TRUNC_U_F32 = 169,
    OP_I32_TRUNC_S_F64 = 170,
    OP_I32_TRUNC_U_F64 = 171,
    OP_I64_EXTEND_S_I32 = 172,
    OP_I64_EXTEND_U_I32 = 173,
    OP_I64_TRUNC_S_F32 = 174,
    OP_I64_TRUNC_U_F32 = 175,
    OP_I64_TRUNC_S_F64 = 176,
    OP_I64_TRUNC_U_F64 = 177,
    OP_F32_CONVERT_S_I32 = 178,
    OP_F32_CONVERT_U_I32 = 179,
    OP_F32_CONVERT_S_I64 = 180,
    OP_F32_CONVERT_U_I64 = 181,
    OP_F32_DEMOTE_F64 = 182,
    OP_F64_CONVERT_S_I32 = 183,
    OP_F64_CONVERT_U_I32 = 184,
    OP_F64_CONVERT_S_I64 = 185,
    OP_F64_CONVERT_U_I64 = 186,
    OP_F64_PROMOTE_F32 = 187,
    OP_I32_REINTERPRET_F32 = 188,
    OP_I64_REINTERPRET_F64 = 189,
    OP_F32_REINTERPRET_I32 = 190,
    OP_F64_REINTERPRET_I64 = 191,
    OP_I32_EXTEND8_S = 192,
    OP_I32_EXTEND16_S = 193,
    OP_I64_EXTEND8_S = 194,
    OP_I64_EXTEND16_S = 195,
    OP_I64_EXTEND32_S = 196,
    OP_BULK_MEMORY = 252,
    OP_ATOMIC = 254,
    ARG_MEMORY_INIT = 8,
    ARG_DATA_DROP = 9,
    ARG_MEMORY_COPY = 10,
    ARG_MEMORY_FILL = 11,
    ARG_TABLE_INIT = 12,
    ARG_ELEM_DROP = 13,
    ARG_TABLE_COPY = 14,
    ARG_ATOMIC_WAKE = 0,
    ARG_I32_ATOMIC_WAIT = 1,
    ARG_I64_ATOMIC_WAIT = 2,
    ARG_I32_ATOMIC_LOAD = 16,
    ARG_I64_ATOMIC_LOAD = 17,
    ARG_I32_ATOMIC_LOAD_8U = 18,
    ARG_I32_ATOMIC_LOAD_16U = 19,
    ARG_I64_ATOMIC_LOAD_8U = 20,
    ARG_I64_ATOMIC_LOAD_16U = 21,
    ARG_I64_ATOMIC_LOAD_32U = 22,
    ARG_I32_ATOMIC_STORE = 23,
    ARG_I64_ATOMIC_STORE = 24,
    ARG_I32_ATOMIC_STORE_8 = 25,
    ARG_I32_ATOMIC_STORE_16 = 26,
    ARG_I64_ATOMIC_STORE_8 = 27,
    ARG_I64_ATOMIC_STORE_16 = 28,
    ARG_I64_ATOMIC_STORE_32 = 29,
    ARG_I32_ATOMIC_RMW_ADD = 30,
    ARG_I64_ATOMIC_RMW_ADD = 31,
    ARG_I32_ATOMIC_RMW_ADD_8U = 32,
    ARG_I32_ATOMIC_RMW_ADD_16U = 33,
    ARG_I64_ATOMIC_RMW_ADD_8U = 34,
    ARG_I64_ATOMIC_RMW_ADD_16U = 35,
    ARG_I64_ATOMIC_RMW_ADD_32U = 36,
    ARG_I32_ATOMIC_RMW_SUB = 37,
    ARG_I64_ATOMIC_RMW_SUB = 38,
    ARG_I32_ATOMIC_RMW_SUB_8U = 39,
    ARG_I32_ATOMIC_RMW_SUB_16U = 40,
    ARG_I64_ATOMIC_RMW_SUB_8U = 41,
    ARG_I64_ATOMIC_RMW_SUB_16U = 42,
    ARG_I64_ATOMIC_RMW_SUB_32U = 43,
    ARG_I32_ATOMIC_RMW_AND = 44,
    ARG_I64_ATOMIC_RMW_AND = 45,
    ARG_I32_ATOMIC_RMW_AND_8U = 46,
    ARG_I32_ATOMIC_RMW_AND_16U = 47,
    ARG_I64_ATOMIC_RMW_AND_8U = 48,
    ARG_I64_ATOMIC_RMW_AND_16U = 49,
    ARG_I64_ATOMIC_RMW_AND_32U = 50,
    ARG_I32_ATOMIC_RMW_OR = 51,
    ARG_I64_ATOMIC_RMW_OR = 52,
    ARG_I32_ATOMIC_RMW_OR_8U = 53,
    ARG_I32_ATOMIC_RMW_OR_16U = 54,
    ARG_I64_ATOMIC_RMW_OR_8U = 55,
    ARG_I64_ATOMIC_RMW_OR_16U = 56,
    ARG_I64_ATOMIC_RMW_OR_32U = 57,
    ARG_I32_ATOMIC_RMW_XOR = 58,
    ARG_I64_ATOMIC_RMW_XOR = 59,
    ARG_I32_ATOMIC_RMW_XOR_8U = 60,
    ARG_I32_ATOMIC_RMW_XOR_16U = 61,
    ARG_I64_ATOMIC_RMW_XOR_8U = 62,
    ARG_I64_ATOMIC_RMW_XOR_16U = 63,
    ARG_I64_ATOMIC_RMW_XOR_32U = 64,
    ARG_I32_ATOMIC_RMW_XCHG = 65,
    ARG_I64_ATOMIC_RMW_XCHG = 66,
    ARG_I32_ATOMIC_RMW_XCHG_8U = 67,
    ARG_I32_ATOMIC_RMW_XCHG_16U = 68,
    ARG_I64_ATOMIC_RMW_XCHG_8U = 69,
    ARG_I64_ATOMIC_RMW_XCHG_16U = 70,
    ARG_I64_ATOMIC_RMW_XCHG_32U = 71,
    ARG_I32_ATOMIC_RMW_CMPXCHG = 72,
    ARG_I64_ATOMIC_RMW_CMPXCHG = 73,
    ARG_I32_ATOMIC_RMW_CMPXCHG_8U = 74,
    ARG_I32_ATOMIC_RMW_CMPXCHG_16U = 75,
    ARG_I64_ATOMIC_RMW_CMPXCHG_8U = 76,
    ARG_I64_ATOMIC_RMW_CMPXCHG_16U = 77,
    ARG_I64_ATOMIC_RMW_CMPXCHG_32U = 78,
    convertOpcode = function(e) {
        const t = opcodeStr[e];
        if (void 0 === t) throw new Error("Invalid opcode " + e);
        return t
    },
    convertOpcodeArray = function(e) {
        const t = [];
        for (let i = 0; i < e.length; i++) {
            const r = e[i];
            let n = r;
            "string" == typeof r && (n = convertOpcode(r)), t.push(n)
        }
        return t
    },
    Uint8ToArray = function(e) {
        return [255 & e]
    },
    Uint32ToArray = function(e) {
        return [255 & e, (65280 & e) >> 8, (16711680 & e) >> 16, (4278190080 & e) >> 24]
    },
    Uint64ToArray = function(e) {
        return [255 & e, (65280 & e) >> 8, (16711680 & e) >> 16, (4278190080 & e) >> 24, (0xff00000000 & e) >> 32, (0xff0000000000 & e) >> 40, (0xff000000000000 & e) >> 48, (0xff00000000000000 & e) >> 56]
    },
    VarUint32ToArray = function(e) {
        const t = [];
        let i = e;
        if (0 == e) return [0];
        for (; i > 0;) {
            let e = 127 & i;
            (i >>= 7) && (e |= 128), t.push(e)
        }
        return t
    },
    VarSint32ToArray = function(e) {
        const t = [];
        let i = e;
        for (;;) {
            if (thisByte = 127 & i, -1 == (i >>= 7) && 64 & thisByte) {
                t.push(thisByte);
                break
            }
            if (!(0 != i || 64 & thisByte)) {
                t.push(thisByte);
                break
            }
            thisByte |= 128, t.push(thisByte)
        }
        return t
    },
    stringToByteArray = function(e) {
        return e.split("").map(function(e) {
            return e.charCodeAt(0)
        })
    },
    VarUint32 = function(e) {
        return "number" == typeof e ? VarUint32ToArray(e) : e instanceof WailVariable ? e.varUint32() : void 0
    };
class WailVariable {
    constructor() {
        this._value = null
    }
    get value() {
        if (null === this._value) throw new Error("Attempted to resolve WailVariable before set");
        return this._value
    }
    set value(e) {
        this._value = e
    }
    i32() {
        return null !== this._value ? this.value : new WailI32(this)
    }
    f32() {
        if (null !== this._value) {
            const e = new Float32Array([this._value]);
            return new Uint8Array(e.buffer)
        }
        return new WailF32(this)
    }
    i64() {
        return null !== this._value ? this.value : new WailI64(this)
    }
    f64() {
        if (null !== this._value) {
            const e = new Float64Array([this._value]);
            return new Uint8Array(e.buffer)
        }
        return new WailF64(this)
    }
    varUint32() {
        return null !== this._value ? VarUint32(this.value) : new WailVarUint32(this)
    }
}
class TypedWailVariable {
    constructor(e) {
        this._parent = e
    }
}
class WailI32 extends TypedWailVariable {
    get value() {
        return Uint32ToArray(this._parent.value)
    }
}
class WailF32 extends TypedWailVariable {
    get value() {
        return Uint32ToArray(this._parent.value)
    }
}
class WailI64 extends TypedWailVariable {
    get value() {
        return Uint64ToArray(this._parent.value)
    }
}
class WailF64 extends TypedWailVariable {
    get value() {
        return Uint64ToArray(this._parent.value)
    }
}
class WailVarUint32 extends TypedWailVariable {
    get value() {
        return VarUint32ToArray(this._parent.value)
    }
}
const BufferReader = class {
    constructor(e) {
        this.inBuffer = null, this.outBuffer = null, void 0 !== e ? (this.inBuffer = new Uint8Array(e), this.outBuffer = new Uint8Array(2 * e.length)) : this.outBuffer = new Uint8Array(1), this.inPos = 0, this._copyPos = 0, this.outPos = 0, this._anchor = null
    }
    load(e) {
        this.inBuffer = new Uint8Array(e), this.outBuffer = new Uint8Array(2 * this.inBuffer.length)
    }
    resize() {
        if (0 == this.outBuffer.length) throw new Error("Attempted to resize 0-length buffer");
        const e = new Uint8Array(Math.ceil(1.25 * this.outBuffer.length));
        for (let t = 0; t < this.outPos; t++) e[t] = this.outBuffer[t];
        this.outBuffer = e
    }
    readUint8() {
        return this.inBuffer[this.inPos++]
    }
    readUint32() {
        return this.inBuffer[this.inPos++] | this.inBuffer[this.inPos++] << 8 | this.inBuffer[this.inPos++] << 16 | this.inBuffer[this.inPos++] << 24
    }
    readVarUint32() {
        let e, t = 0,
            i = 0;
        do {
            t |= (127 & (e = this.readUint8())) << i, i += 7
        } while (128 & e);
        return t
    }
    readUint64() {
        return this.inBuffer[this.inPos++] | this.inBuffer[this.inPos++] << 8 | this.inBuffer[this.inPos++] << 16 | this.inBuffer[this.inPos++] << 24 | this.inBuffer[this.inPos++] << 32 | this.inBuffer[this.inPos++] << 40 | this.inBuffer[this.inPos++] << 48 | this.inBuffer[this.inPos++] << 56
    }
    readBytes(e) {
        const t = new Uint8Array(e);
        for (let i = 0; i < e; i++) t[i] = this.inBuffer[this.inPos++];
        return t
    }
    copyBuffer(e) {
        for (; e.length + this.outPos > this.outBuffer.length;) this.resize();
        for (let t = 0; t < e.length; t++, this.outPos++) this.outBuffer[this.outPos] = e[t];
        this.updateCopyPosition()
    }
    commitBytes() {
        for (; this.inPos - this._copyPos + this.outPos > this.outBuffer.length;) this.resize();
        for (; this._copyPos < this.inPos; this._copyPos++, this.outPos++) this.outBuffer[this.outPos] = this.inBuffer[this._copyPos]
    }
    updateCopyPosition() {
        this._copyPos = this.inPos
    }
    setAnchor() {
        this._anchor = this.outPos
    }
    readFromAnchor() {
        return this.outBuffer.slice(this._anchor, this.outPos)
    }
    writeAtAnchor(e) {
        for (; e.length + this.outPos > this.outBuffer.length;) this.resize();
        for (let t = 0; t < e.length; t++) this.outBuffer[this._anchor + t] = e[t];
        this.outPos = this._anchor + e.length
    }
    write() {
        return this.outBuffer.slice(0, this.outPos)
    }
};
class WailParser extends BufferReader {
    constructor(e) {
        super(e), this._finished = !1, this._newSections = [], this._removeSectionIds = [], this._resolvedTables = !1, this._importFuncCount = 0, this._importFuncNewCount = 0, this._importGlobalCount = 0, this._importGlobalNewCount = 0, this._globalFunctionCallback = null, this._functionCallbacks = [], this._globalInstructionCallback = null, this._instructionCallbacks = {}, this._sectionOptions = {};
        for (let e = 0; e <= MAX_SECTION_ID; e++) this._sectionOptions[e] = {
            newEntries: [],
            existingEntries: [],
            pending: []
        };
        this._requiredSectionFlags = 0, this._optionalSectionFlags = 0, this._parsedSections = 0, this.__variables = []
    }
    parse() {
        const e = this.readUint32();
        this.readUint32();
        if (1836278016 != e) throw new Error("Invalid magic. Probably not a WebAssembly binary");
        for (; this.inPos < this.inBuffer.length;) this._readSection();
        this.commitBytes(), this._finished = !0
    }
    removeSection(e) {
        if ("number" != typeof e) throw new Error("Invalid argument to removeSection()");
        this._removeSectionIds.push(e)
    }
    addTypeEntry(e) {
        const t = {},
            i = e.form;
        t.form = "number" == typeof i ? i : convertValueType(i);
        const r = e.params;
        if (r instanceof Array) {
            const e = [];
            for (let t = 0; t < r.length; t++) {
                const i = r[t];
                "number" == typeof i ? e.push(i) : e.push(convertValueType(i))
            }
            t.params = e
        } else t.params = [];
        const n = e.returnType;
        "number" == typeof n ? t.returnType = n : "string" == typeof n && (t.returnType = convertValueType(n));
        const _ = this._createVariable();
        return t.variable = _, this._sectionOptions[SECTION_TYPE].newEntries.push(t), this._requiredSectionFlags |= 1 << SECTION_TYPE, _
    }
    editTypeEntry(e, t) {
        const i = {};
        if ("number" != typeof e) throw new Error("Invalid index in editTypeEntry()");
        i.index = e;
        const r = t.params;
        r instanceof Array ? i.params = r : i.params = [];
        const n = t.returnType;
        n && (i.returnType = n), this._sectionOptions[SECTION_TYPE].existingEntries.push(i), this._optionalSectionFlags |= 1 << SECTION_TYPE
    }
    addImportEntry(e) {
        const t = {},
            i = e.moduleStr;
        if (!("string" == typeof i || i instanceof String)) throw new Error("Invalid moduleStr");
        t.moduleStr = i;
        const r = e.fieldStr;
        if (!("string" == typeof r || r instanceof String)) throw new Error("Invalid fieldStr");
        t.fieldStr = r;
        const n = e.kind;
        let _;
        _ = "number" == typeof n ? n : convertKind(n);
        let a = e.type;
        switch (t.kind = _, _) {
            case KIND_FUNC:
                if (this._importFuncNewCount++, "number" == typeof a) t.type = a;
                else if (a instanceof WailVarUint32) t.type = a;
                else {
                    if (!(a instanceof WailVariable)) throw new Error("Invalid type");
                    t.type = a.varUint32()
                }
                break;
            case KIND_GLOBAL:
                if (this._importGlobalNewCount++, "number" != typeof a) throw new Error("Invalid type");
                if (t.type = a, 0 !== e.mutability && 1 !== e.mutability && !0 !== e.mutability && !1 !== e.mutability) throw new Error("Invalid mutability");
                t.mutability = e.mutability;
                break;
            case KIND_MEMORY:
                throw new Error("Adding new memory object not currently supported");
            case KIND_TABLE:
                throw new Error("Adding new table object not currently supported");
            default:
                throw new Error("Invalid kind")
        }
        const o = this._createVariable();
        return t.variable = o, this._sectionOptions[SECTION_IMPORT].newEntries.push(t), this._requiredSectionFlags |= 1 << SECTION_IMPORT, this._importFuncNewCount > 0 && (this._optionalSectionFlags |= 1 << SECTION_EXPORT, this._optionalSectionFlags |= 1 << SECTION_ELEMENT, this._optionalSectionFlags |= 1 << SECTION_CODE, this._optionalSectionFlags |= 1 << SECTION_START), this._importGlobalNewCount > 0 && (this._optionalSectionFlags |= 1 << SECTION_EXPORT, this._optionalSectionFlags |= 1 << SECTION_CODE), o
    }
    editImportEntry(e, t) {
        const i = {};
        if (i.index = e, "number" != typeof e && !(e instanceof WailVariable)) throw new Error("Invalid index in editImportEntry()");
        const r = t.moduleStr;
        ("string" == typeof r || r instanceof String) && (i.moduleStr = stringToByteArray(r));
        const n = t.fieldStr;
        ("string" == typeof n || n instanceof String) && (i.fieldStr = stringToByteArray(n)), this._sectionOptions[SECTION_IMPORT].existingEntries.push(i), this._optionalSectionFlags |= 1 << SECTION_IMPORT
    }
    addFunctionEntry(e) {
        const t = {},
            i = e.type;
        if ("number" == typeof i) t.type = i;
        else if (i instanceof WailVarUint32) t.type = i;
        else {
            if (!(i instanceof WailVariable)) throw new Error("Invalid type");
            t.type = i.varUint32()
        }
        const r = this._createVariable();
        return t.variable = r, this._sectionOptions[SECTION_FUNCTION].newEntries.push(t), this._requiredSectionFlags |= 1 << SECTION_FUNCTION, r
    }
    editFunctionEntry(e, t) {
        const i = {};
        if (i.index = e, "number" != typeof e && !(e instanceof WailVariable)) throw new Error("Invalid index in editFunctionEntry()");
        const r = t.type;
        if ("number" != typeof r) throw new Error("Invalid type in editFunctionEntry()");
        i.type = r, this._sectionOptions[SECTION_FUNCTION].existingEntries.push(i), this._optionalSectionFlags |= 1 << SECTION_FUNCTION
    }
    getFunctionIndex(e) {
        if (this._finished) {
            if (e instanceof WailVariable) return e; {
                const t = this._createVariable;
                return t.value = this._getAdjustedFunctionIndex(e), t
            }
        }
        const t = this._createVariable();
        if ("number" != typeof e) throw new Error("Invalid index in getFunctionIndex()");
        const i = {
            oldIndex: e,
            variable: t
        };
        return this._sectionOptions[SECTION_FUNCTION].pending.push(i), this._optionalSectionFlags |= 1 << SECTION_IMPORT, t
    }
    addGlobalEntry(e) {
        const t = {
            globalType: {}
        };
        if (void 0 === e.globalType) throw new Error("Invalid globalType");
        "number" == typeof e.globalType.contentType ? t.globalType.contentType = e.globalType.contentType : t.globalType.contentType = convertValueType(e.globalType.contentType);
        const i = e.globalType.mutability;
        if (1 == i) t.globalType.mutability = 1;
        else {
            if (0 != i) throw new Error("Invalid mutability");
            t.globalType.mutability = 0
        }
        e.initExpr instanceof Array ? t.initExpr = convertOpcodeArray(e.initExpr) : t.initExpr = [OP_I32_CONST, VarUint32(0), OP_END];
        const r = this._createVariable();
        return t.variable = r, this._sectionOptions[SECTION_GLOBAL].newEntries.push(t), this._requiredSectionFlags |= 1 << SECTION_GLOBAL, r
    }
    editGlobalEntry(e, t) {
        const i = {};
        if ("number" == typeof e) console.warn("Using raw indexes in editGlobalEntry() can have unpredictable results. Consider using getGlobalIndex() instead");
        else if (!(e instanceof WailVariable)) throw new Error("Invalid globalIndex in addCodeEntry()");
        if (i.index = e, i.globalType = {}, void 0 === t.globalType) throw new Error("Invalid globalType");
        "number" == typeof t.globalType.contentType ? i.globalType.contentType = t.globalType.contentType : i.globalType.contentType = convertValueType(t.globalType.contentType);
        const r = t.globalType.mutability;
        if (1 == r) i.globalType.mutability = 1;
        else {
            if (0 != r) throw new Error("Invalid mutability");
            i.globalType.mutability = 0
        }
        this._sectionOptions[SECTION_GLOBAL].existingEntries.push(i), this._requiredSectionFlags |= 1 << SECTION_GLOBAL
    }
    getGlobalIndex(e) {
        if (this._finished) return e instanceof WailVariable ? e.value : this._getAdjustedGlobalIndex(e);
        const t = this._createVariable();
        if ("number" != typeof e) throw new Error("Invalid index in getGlobalIndex()");
        const i = {
            oldIndex: e,
            variable: t
        };
        return this._sectionOptions[SECTION_GLOBAL].pending.push(i), this._optionalSectionFlags |= 1 << SECTION_IMPORT, t
    }
    addExportEntry(e, t) {
        const i = {};
        if (!("string" == typeof t.fieldStr || t.fieldStr instanceof String)) throw new Error("Invalid fieldStr");
        if (i.fieldStr = t.fieldStr, "number" == typeof t.kind ? i.kind = t.kind : i.kind = convertKind(t.kind), "number" == typeof e) i.index = e;
        else if (e instanceof WailVarUint32) i.index = e;
        else {
            if (!(e instanceof WailVariable)) throw new Error("Invalid type");
            i.index = e.varUint32()
        }
        const r = this._createVariable();
        return i.variable = r, this._sectionOptions[SECTION_EXPORT].newEntries.push(i), this._requiredSectionFlags |= 1 << SECTION_EXPORT, r
    }
    editExportEntry(e, t) {
        const i = {};
        if (i.index = e, "number" != typeof e && !(e instanceof WailVariable)) throw new Error("Invalid index in editExportEntry()");
        const r = t.fieldStr;
        ("string" == typeof r || r instanceof String) && (i.fieldStr = stringToByteArray(r)), i.kind = t.kind, i.funcIndex = t.index, this._sectionOptions[SECTION_EXPORT].existingEntries.push(i), this._optionalSectionFlags |= 1 << SECTION_EXPORT
    }
    editStartEntry(e) {
        if ("number" != typeof e && !(e instanceof WailVariable)) throw new Error("Invalid index in editStartEntry()");
        this._sectionOptions[SECTION_START].existingEntries.push(e), this._requiredSectionFlags |= 1 << SECTION_START
    }
    addElementEntry(e) {
        const t = this._createVariable();
        return e.variable = t, this._sectionOptions[SECTION_ELEMENT].newEntries.push(e), this._requiredSectionFlags |= 1 << SECTION_ELEMENT, t
    }
    editElementEntry(e, t) {
        const i = {};
        if (i.index = e, "number" != typeof e && !(e instanceof WailVariable)) throw new Error("Invalid index in editElementEntry()");
        i.elems = [], this._sectionOptions[SECTION_ELEMENT].existingEntries.push(i), this._optionalSectionFlags |= 1 << SECTION_ELEMENT
    }
    addCodeEntry(e, t) {
        const i = {};
        if ("number" == typeof e) console.warn("Using raw indexes in addCodeEntry() can have unpredictable results. Consider using getFunctionIndex() instead");
        else if (!(e instanceof WailVariable)) throw new Error("Invalid funcIndex in addCodeEntry()");
        i.index = e;
        const r = t.locals;
        if (r instanceof Array) {
            const e = [];
            for (let t = 0; t < r.length; t++) {
                const i = r[t];
                if ("number" == typeof i) e.push(i);
                else {
                    if ("string" != typeof i) throw new Error("Invalid local entry in addCodeEntry()");
                    e.push(convertValueType(i))
                }
            }
            i.locals = e
        } else i.locals = [];
        const n = t.code;
        if (!(n instanceof Array)) throw new Error("Invalid code");
        i.code = convertOpcodeArray(n);
        const _ = this._createVariable();
        return i.variable = _, this._sectionOptions[SECTION_CODE].newEntries.push(i), this._requiredSectionFlags |= 1 << SECTION_CODE, _
    }
    editCodeEntry(e, t) {
        const i = {};
        if ("number" == typeof e) console.warn("Using raw indexes in editCodeEntry() can have unpredictable results. Consider using getFunctionIndex() instead");
        else if (!(e instanceof WailVariable)) throw new Error("Invalid funcIndex in addCodeEntry()");
        i.index = e;
        const r = t.locals;
        if (r instanceof Array) {
            const e = [];
            for (let t = 0; t < r.length; t++) {
                const i = r[t];
                if ("number" == typeof i) e.push(i);
                else {
                    if ("string" != typeof i) throw new Error("Invalid local entry in addCodeEntry()");
                    e.push(convertValueType(i))
                }
            }
            i.locals = e
        } else i.locals = [];
        const n = t.code;
        if (!(n instanceof Array)) throw new Error("Invalid code");
        i.code = convertOpcodeArray(n), this._sectionOptions[SECTION_CODE].existingEntries.push(i), this._optionalSectionFlags |= 1 << SECTION_IMPORT, this._optionalSectionFlags |= 1 << SECTION_CODE
    }
    addDataEntry(e) {
        const t = this._createVariable();
        return e.variable = t, this._sectionOptions[SECTION_DATA].newEntries.push(e), this._requiredSectionFlags |= 1 << SECTION_DATA, t
    }
    editDataEntry(e, t) {
        const i = {};
        if ("number" != typeof e) throw new Error("Invalid index in editTypeEntry()");
        i.index = e, "string" == typeof t.data ? i.data = stringToByteArray(t.data) : i.data = t.data, this._sectionOptions[SECTION_DATA].existingEntries.push(i), this._optionalSectionFlags |= 1 << SECTION_DATA
    }
    addCodeElementParser(e, t) {
        if ("function" != typeof t) throw new Error("Bad callback in addCodeElementParser()");
        if (null === e) this._globalFunctionCallback = t;
        else {
            if (!("number" == typeof e || e instanceof WailVariable)) throw new Error("Bad id " + e + " in addCodeElementParser()"); {
                const i = {};
                i.index = e, i.callback = t, this._functionCallbacks.push(i)
            }
        }
        this._optionalSectionFlags |= 1 << SECTION_IMPORT, this._optionalSectionFlags |= 1 << SECTION_CODE
    }
    addInstructionParser(e, t) {
        if ("function" != typeof t) throw new Error("Bad callback in addInstructionParser()");
        if (null === e) this._globalInstructionCallback = t;
        else {
            if (isNaN(e) && !(e instanceof WailVariable)) throw new Error("Bad opcode " + e + " in addCodeElementParser()");
            this._instructionCallbacks[e] = t
        }
        this._optionalSectionFlags |= 1 << SECTION_CODE
    }
    addRawSection(e, t) {
        const i = {};
        if ("number" != typeof e) throw new Error("Bad section index " + index + " in addRawSection()");
        i.id = e, i.bytes = t, this._newSections.push(i)
    }
    _createVariable() {
        const e = this.__variables.length,
            t = new WailVariable(this, e);
        return this.__variables.push(t), t
    }
    _getVariable(e) {
        return this.__variables[e]
    }
    _setVariable(e, t) {
        this.__variables[e] = t
    }
    _expandArrayVariables(e) {
        for (let t = 0; t < e.length; t++) {
            const i = e[t];
            if (i instanceof Array) e.splice(t, 1), e.splice(t, 0, ...i);
            else if (i instanceof TypedWailVariable) {
                const r = i;
                e.splice(t, 1), e.splice(t, 0, ...r.value)
            } else if (i instanceof WailVariable) throw new Error("Untyped WailVariable in _expandArrayVariables()")
        }
        return e
    }
    _readSection() {
        this.commitBytes();
        const e = this.readUint8();
        if (e > MAX_SECTION_ID) throw new Error("Illegal section ID " + e + ". Probably parsing incorrectly");
        let t;
        if (this._removeSectionIds.includes(e)) return t = this.readVarUint32(), this.readBytes(t), void this.updateCopyPosition();
        let i = !1;
        if ((this._requiredSectionFlags & 1 << e || this._optionalSectionFlags & 1 << e) && (i = !0), e != SECTION_DATACOUNT)
            for (let t = 0; t < e; t++) {
                const i = 1 << t,
                    r = this._requiredSectionFlags & i;
                if (r && !(r & this._parsedSections)) {
                    switch (t) {
                        case SECTION_TYPE:
                            this._addTypeSection();
                            break;
                        case SECTION_IMPORT:
                            this._addImportSection();
                            break;
                        case SECTION_FUNCTION:
                            this._addFunctionSection();
                            break;
                        case SECTION_GLOBAL:
                            this._addGlobalSection();
                            break;
                        case SECTION_EXPORT:
                            this._addExportSection();
                            break;
                        case SECTION_START:
                            this._addStartSection();
                            break;
                        case SECTION_ELEMENT:
                            this._addElementSection();
                            break;
                        case SECTION_CODE:
                            this._addCodeSection();
                            break;
                        case SECTION_DATA:
                            this._addDataSection();
                            break;
                        default:
                            throw new Error("Attempted to add unhandled section")
                    }
                    this._parsedSections |= i, this.copyBuffer([e])
                }
            }
        for (let t = 0; t < this._newSections.length; t++) {
            const i = this._newSections[t];
            if (e > i.id) {
                const e = i.bytes,
                    t = VarUint32ToArray(e.length);
                this.copyBuffer([i.id]), this.copyBuffer(t), this.copyBuffer(e)
            }
        }
        if (!i) return t = this.readVarUint32(), void this.readBytes(t);
        switch (e > SECTION_IMPORT && 0 == this._resolvedTables && this._resolveTableIndices(), e) {
            case SECTION_TYPE:
                this._parseTypeSection();
                break;
            case SECTION_IMPORT:
                this._parseImportSection();
                break;
            case SECTION_FUNCTION:
                this._parseFunctionSection();
                break;
            case SECTION_GLOBAL:
                this._parseGlobalSection();
                break;
            case SECTION_EXPORT:
                this._parseExportSection();
                break;
            case SECTION_START:
                this._parseStartSection();
                break;
            case SECTION_ELEMENT:
                this._parseElementSection();
                break;
            case SECTION_CODE:
                this._parseCodeSection();
                break;
            case SECTION_DATA:
                this._parseDataSection();
                break;
            default:
                throw new Error("Attempted to parse unhandled section")
        }
        this._parsedSections |= 1 << e
    }
    _resolveTableIndices() {
        const e = this._sectionOptions[SECTION_FUNCTION].pending;
        for (let t = 0; t < e.length; t++) {
            const i = e[t].oldIndex;
            e[t].variable.value = this._getAdjustedFunctionIndex(i)
        }
        const t = this._sectionOptions[SECTION_GLOBAL].pending;
        for (let e = 0; e < t.length; e++) {
            const i = t[e].oldIndex;
            t[e].variable.value = this._getAdjustedGlobalIndex(i)
        }
        this._resolvedTables = !0
    }
    _addTypeSection() {
        const e = new BufferReader,
            t = this._sectionOptions[SECTION_TYPE].newEntries,
            i = VarUint32ToArray(t.length);
        e.copyBuffer(i);
        for (let i = 0; i < t.length; i++) {
            const r = t[i],
                n = r.form,
                _ = r.params;
            let a = null;
            void 0 !== r.returnType && (a = r.returnType), r.variable instanceof WailVariable && (r.variable.value = oldCount + i), e.copyBuffer(Uint8ToArray(n)), e.copyBuffer(VarUint32ToArray(_.length)), e.copyBuffer(_), null !== a ? (e.copyBuffer(Uint8ToArray(1)), e.copyBuffer(Uint8ToArray(a))) : e.copyBuffer(Uint8ToArray(0))
        }
        const r = e.write(),
            n = VarUint32ToArray(r.length);
        this.copyBuffer([SECTION_TYPE]), this.copyBuffer(n), this.copyBuffer(r)
    }
    _parseTypeSection() {
        this.commitBytes();
        const e = this.readVarUint32(),
            t = this.inPos,
            i = this.readVarUint32(),
            r = this.inPos - t,
            n = this.readBytes(e - r),
            _ = new BufferReader(n),
            a = this._sectionOptions[SECTION_TYPE].newEntries,
            o = this._sectionOptions[SECTION_TYPE].existingEntries,
            s = i + a.length;
        _.copyBuffer(VarUint32ToArray(s));
        for (let e = 0; e < i; e++) {
            const t = _.readUint8();
            let i = _.readVarUint32(),
                r = [];
            for (let e = 0; e < i; e++) r.push(_.readUint8());
            let n = _.readUint8(),
                a = null;
            if (1 == n) a = _.readUint8();
            else if (0 != n) throw new Error("Invalid returnCount");
            for (let t = 0; t < o.length; t++) {
                const i = o[t];
                e == i.index && (void 0 !== i.params && (r = mod.params), void 0 !== i.returnType && (n = 1, a = mod.returnType))
            }
            _.copyBuffer(Uint8ToArray(t)), _.copyBuffer(VarUint32ToArray(r.length)), _.copyBuffer(r), n ? (_.copyBuffer(Uint8ToArray(1)), _.copyBuffer(Uint8ToArray(a))) : _.copyBuffer(Uint8ToArray(0))
        }
        for (let e = 0; e < a.length; e++) {
            const t = a[e],
                r = t.form,
                n = t.params;
            let o = null;
            void 0 !== t.returnType && (o = t.returnType), t.variable instanceof WailVariable && (t.variable.value = i + e), _.copyBuffer(Uint8ToArray(r)), _.copyBuffer(VarUint32ToArray(n.length)), _.copyBuffer(n), null !== o ? (_.copyBuffer(Uint8ToArray(1)), _.copyBuffer(Uint8ToArray(o))) : _.copyBuffer(Uint8ToArray(0))
        }
        const c = _.write(),
            l = VarUint32ToArray(c.length);
        this.copyBuffer(l), this.copyBuffer(c)
    }
    _addImportSection() {
        const e = new BufferReader,
            t = this._sectionOptions[SECTION_IMPORT].newEntries,
            i = VarUint32ToArray(t.length);
        e.copyBuffer(i);
        let r = 0,
            n = 0;
        for (let i = 0; i < t.length; i++) {
            const _ = t[i],
                a = stringToByteArray(_.moduleStr),
                o = VarUint32ToArray(a.length),
                s = stringToByteArray(_.fieldStr),
                c = VarUint32ToArray(s.length),
                l = [_.kind];
            let O;
            if (_.kind == KIND_FUNC) {
                if (_.type instanceof TypedWailVariable) O = _.type.value;
                else {
                    if (_.type instanceof WailVariable) throw new Error("Untyped WailVariable in _addImportSection()");
                    O = VarUint32ToArray(_.type)
                }
                _.variable instanceof WailVariable && (_.variable.value = this._importFuncCount + r++)
            } else _.kind == KIND_GLOBAL && (O = [_.type, _.mutability], _.variable instanceof WailVariable && (_.variable.value = this._importGlobalCount + n++));
            e.copyBuffer(o), e.copyBuffer(a), e.copyBuffer(c), e.copyBuffer(s), e.copyBuffer(l), e.copyBuffer(O)
        }
        const _ = e.write(),
            a = VarUint32ToArray(_.length);
        this.copyBuffer([SECTION_IMPORT]), this.copyBuffer(a), this.copyBuffer(_);
        const o = this._sectionOptions[SECTION_FUNCTION].pending;
        for (let e = 0; e < o.length; e++) {
            const t = o[e].oldIndex;
            o[e].variable.value = this._getAdjustedFunctionIndex(t)
        }
        const s = this._sectionOptions[SECTION_GLOBAL].pending;
        for (let e = 0; e < s.length; e++) {
            const t = s[e].oldIndex;
            s[e].variable.value = this._getAdjustedGlobalIndex(t)
        }
    }
    _parseImportSection() {
        this.commitBytes();
        const e = this.readVarUint32(),
            t = this.inPos,
            i = this.readVarUint32(),
            r = this.inPos - t,
            n = this.readBytes(e - r),
            _ = new BufferReader(n),
            a = this._sectionOptions[SECTION_IMPORT].newEntries,
            o = this._sectionOptions[SECTION_IMPORT].existingEntries;
        for (let e = 0; e < i; e++) {
            _.commitBytes();
            let t = _.readVarUint32(),
                i = _.readBytes(t),
                r = _.readVarUint32(),
                n = _.readBytes(r);
            for (let _ = 0; _ < o.length; _++) {
                const a = o[_];
                e == a.index && (void 0 !== a.moduleStr && (i = a.moduleStr, t = a.moduleStr.length), void 0 !== a.fieldStr && (n = a.fieldStr, r = a.fieldStr.length))
            }
            _.copyBuffer(VarUint32ToArray(t)), _.copyBuffer(i), _.copyBuffer(VarUint32ToArray(r)), _.copyBuffer(n);
            const a = _.readUint8();
            if (a == KIND_FUNC) this._importFuncCount++, _.readVarUint32();
            else if (a == KIND_TABLE) {
                _.readUint8();
                const e = _.readUint8();
                _.readVarUint32(), e && _.readVarUint32()
            } else if (a == KIND_MEMORY) {
                const e = _.readUint8();
                _.readVarUint32(), e && _.readVarUint32()
            } else {
                if (a != KIND_GLOBAL) throw "Invalid type kind: " + a;
                this._importGlobalCount++, _.readUint8(), _.readUint8()
            }
        }
        let s = i,
            c = 0,
            l = 0;
        for (let e = 0; e < a.length; e++, s++) {
            _.commitBytes();
            const t = a[e],
                i = stringToByteArray(t.moduleStr),
                r = VarUint32ToArray(i.length),
                n = stringToByteArray(t.fieldStr),
                o = VarUint32ToArray(n.length),
                s = [t.kind];
            let O;
            if (t.kind == KIND_FUNC) {
                if (t.type instanceof TypedWailVariable) O = t.type.value;
                else {
                    if (t.type instanceof WailVariable) throw new Error("Untyped WailVariable in _addImportSection()");
                    O = VarUint32ToArray(t.type)
                }
                t.variable instanceof WailVariable && (t.variable.value = this._importFuncCount + c), c++
            } else t.kind == KIND_GLOBAL && (O = [t.type, t.mutability], t.variable instanceof WailVariable && (t.variable.value = this._importGlobalCount + l), l++);
            _.copyBuffer(r), _.copyBuffer(i), _.copyBuffer(o), _.copyBuffer(n), _.copyBuffer(s), _.copyBuffer(O)
        }
        const O = VarUint32ToArray(s),
            f = _.write(),
            I = VarUint32ToArray(O.length + f.length);
        this.copyBuffer(I), this.copyBuffer(O), this.copyBuffer(f), 0 == this._resolvedTables && this._resolveTableIndices()
    }
    _addFunctionSection() {
        const e = new BufferReader,
            t = this._sectionOptions[SECTION_FUNCTION].newEntries,
            i = VarUint32ToArray(t.length);
        e.copyBuffer(i);
        for (let i = 0; i < t.length; i++) {
            let r, n = t[i];
            if (n.type instanceof TypedWailVariable) r = n.type.value;
            else {
                if (n.type instanceof WailVariable) throw new Error("Untyped WailVariable in _parseFunctionSection()");
                r = VarUint32ToArray(n.type)
            }
            if (e.copyBuffer(r), n.variable instanceof WailVariable) {
                const e = newCount + this._importFuncCount;
                n.variable.value = this._getAdjustedFunctionIndex(e)
            }
        }
        const r = e.write(),
            n = VarUint32ToArray(r.length);
        this.copyBuffer([SECTION_FUNCTION]), this.copyBuffer(n), this.copyBuffer(r)
    }
    _parseFunctionSection() {
        this.commitBytes();
        const e = this._sectionOptions[SECTION_FUNCTION].newEntries,
            t = this._sectionOptions[SECTION_FUNCTION].existingEntries,
            i = this.readVarUint32(),
            r = this.inPos,
            n = this.readVarUint32(),
            _ = this.inPos - r,
            a = this.readBytes(i - _),
            o = new BufferReader(a);
        for (let e = 0; e < n; e++) {
            o.commitBytes();
            let i = o.readVarUint32();
            for (let r = 0; r < t.length; r++) {
                const n = t[r];
                e == n.index && (i = n.type)
            }
            o.copyBuffer(VarUint32ToArray(i))
        }
        let s = n;
        for (let t = 0; t < e.length; t++, s++) {
            let i, r = e[t];
            if (r.type instanceof TypedWailVariable) i = r.type.value;
            else {
                if (r.type instanceof WailVariable) throw new Error("Untyped WailVariable in _parseFunctionSection()");
                i = VarUint32ToArray(r.type)
            }
            if (o.copyBuffer(i), r.variable instanceof WailVariable) {
                const e = s + this._importFuncCount;
                r.variable.value = this._getAdjustedFunctionIndex(e)
            }
        }
        const c = VarUint32ToArray(s),
            l = o.write(),
            O = VarUint32ToArray(c.length + l.length);
        this.copyBuffer(O), this.copyBuffer(c), this.copyBuffer(l)
    }
    _addGlobalSection() {
        const e = new BufferReader,
            t = this._sectionOptions[SECTION_GLOBAL].newEntries,
            i = VarUint32ToArray(t.length);
        e.copyBuffer(i);
        for (let i = 0; i < t.length; i++) {
            const r = t[i];
            e.copyBuffer(Uint8ToArray(r.globalType.contentType)), e.copyBuffer(Uint8ToArray(r.globalType.mutability));
            const n = this._expandArrayVariables(r.initExpr);
            e.copyBuffer(n), r.variable instanceof WailVariable && (r.variable.value = this._importGlobalCount + i)
        }
        const r = e.write(),
            n = VarUint32ToArray(r.length);
        this.copyBuffer([SECTION_GLOBAL]), this.copyBuffer(n), this.copyBuffer(r)
    }
    _parseGlobalSection() {
        this.commitBytes();
        const e = this.readVarUint32(),
            t = this.inPos,
            i = this.readVarUint32(),
            r = this.inPos - t,
            n = this.readBytes(e - r),
            _ = new BufferReader(n),
            a = this._sectionOptions[SECTION_GLOBAL].newEntries,
            o = this._sectionOptions[SECTION_GLOBAL].existingEntries,
            s = i + a.length;
        _.copyBuffer(VarUint32ToArray(s));
        for (let e = 0; e < i; e++) {
            let t, i;
            for (let r = 0; r < o.length; r++) {
                const n = o[r];
                let _ = n.index;
                _ instanceof WailVariable && (_ = _.value), e == _ && (t = n.globalType.contentType, i = n.globalType.mutability)
            }
            _.readUint8();
            void 0 !== t && _.copyBuffer([t]), _.commitBytes();
            let r;
            _.readUint8();
            void 0 !== i && _.copyBuffer([i]);
            do {
                r = this._readInstruction(_)
            } while (r[0] != OP_END);
            _.commitBytes()
        }
        for (let e = 0; e < a.length; e++) {
            const t = a[e];
            _.copyBuffer([t.globalType.contentType]), _.copyBuffer([t.globalType.mutability]), _.copyBuffer(this._expandArrayVariables(t.initExpr)), t.variable instanceof WailVariable && (t.variable.value = this._importGlobalCount + i + e)
        }
        const c = _.write(),
            l = VarUint32ToArray(c.length);
        this.copyBuffer(l), this.copyBuffer(c)
    }
    _addExportSection() {
        const e = new BufferReader,
            t = this._sectionOptions[SECTION_EXPORT].newEntries,
            i = VarUint32ToArray(t.length);
        e.copyBuffer(i);
        for (let i = 0; i < t.length; i++) {
            const r = t[i],
                n = stringToByteArray(r.fieldStr),
                _ = VarUint32ToArray(n.length),
                a = Uint8ToArray(r.kind);
            let o;
            if (r.index instanceof TypedWailVariable) o = r.index.value;
            else {
                if (r.index instanceof WailVariable) throw new Error("Untyped WailVariable in _parseExportSection()");
                o = VarUint32ToArray(r.index)
            }
            e.copyBuffer(_), e.copyBuffer(n), e.copyBuffer(a), e.copyBuffer(o)
        }
        const r = e.write(),
            n = VarUint32ToArray(r.length);
        this.copyBuffer([SECTION_EXPORT]), this.copyBuffer(n), this.copyBuffer(r)
    }
    _parseExportSection() {
        this.commitBytes();
        const e = this.readVarUint32(),
            t = this.readBytes(e),
            i = new BufferReader(t),
            r = i.readVarUint32(),
            n = this._sectionOptions[SECTION_EXPORT].newEntries,
            _ = this._sectionOptions[SECTION_EXPORT].existingEntries,
            a = r + n.length;
        i.copyBuffer(VarUint32ToArray(a));
        for (let e = 0; e < r; e++) {
            i.commitBytes();
            let t = i.readVarUint32(),
                r = i.readBytes(t),
                n = i.readUint8(),
                a = i.readVarUint32();
            for (let i = 0; i < _.length; i++) {
                const o = _[i];
                e == o.index && (void 0 !== o.fieldStr && (r = o.fieldStr, t = o.fieldStr.length), void 0 !== o.kind && (n = o.kind), void 0 !== o.funcIndex && (a = o.funcIndex))
            }
            let o = a;
            a instanceof WailVariable ? o = a.value : n == KIND_FUNC ? o = this._getAdjustedFunctionIndex(a) : n == KIND_GLOBAL && (o = this._getAdjustedGlobalIndex(a)), i.copyBuffer(VarUint32ToArray(t)), i.copyBuffer(r), i.copyBuffer([n]), i.copyBuffer(VarUint32ToArray(o))
        }
        for (let e = 0; e < n.length; e++) {
            const t = n[e],
                r = stringToByteArray(t.fieldStr),
                _ = VarUint32ToArray(r.length),
                a = Uint8ToArray(t.kind);
            let o;
            if (t.index instanceof TypedWailVariable) o = t.index.value;
            else {
                if (t.index instanceof WailVariable) throw new Error("Untyped WailVariable in _parseExportSection()");
                o = VarUint32ToArray(t.index)
            }
            i.copyBuffer(_), i.copyBuffer(r), i.copyBuffer(a), i.copyBuffer(o)
        }
        const o = i.write(),
            s = VarUint32ToArray(o.length);
        this.copyBuffer(s), this.copyBuffer(o)
    }
    _parseStartSection() {
        this.commitBytes();
        this.readVarUint32();
        const e = this.readVarUint32(),
            t = this._sectionOptions[SECTION_START].existingEntries;
        let i;
        if (t.length > 0)
            for (let e = 0; e < t.length; e++) {
                const r = t[e];
                if ("number" == typeof r) i = r;
                else {
                    if (!(r instanceof WailVariable)) throw new Error("Invalid function index in _parseStartSection()");
                    i = r.value
                }
            } else i = this._getAdjustedFunctionIndex(e);
        const r = VarUint32ToArray(i),
            n = VarUint32ToArray(r.length);
        this.copyBuffer(n), this.copyBuffer(r)
    }
    _addElementSection() {
        const e = new BufferReader,
            t = this._sectionOptions[SECTION_ELEMENT].newEntries,
            i = VarUint32ToArray(t.length);
        e.copyBuffer(i);
        for (let i = 0; i < t.length; i++, newCount++) {
            const r = t[i],
                n = r.index;
            if (0 != n) throw new Error("Unsupported element index " + n);
            const _ = r.offset,
                a = this._expandArrayVariables(r.elems),
                o = a.length;
            e.copyBuffer(VarUint32ToArray(n)), e.copyBuffer(_), e.copyBuffer(VarUint32ToArray(o)), e.copyBuffer(a)
        }
        const r = e.write(),
            n = VarUint32ToArray(r.length);
        this.copyBuffer([SECTION_ELEMENT]), this.copyBuffer(n), this.copyBuffer(r)
    }
    _parseElementSection() {
        this.commitBytes();
        const e = this.readVarUint32(),
            t = this.inPos,
            i = this.readVarUint32(),
            r = this.inPos - t,
            n = this.readBytes(e - r),
            _ = new BufferReader(n),
            a = this._sectionOptions[SECTION_ELEMENT].newEntries,
            o = this._sectionOptions[SECTION_ELEMENT].existingEntries;
        for (let e = 0; e < i; e++) {
            let t;
            _.readVarUint32();
            do {
                t = this._readInstruction(_)
            } while (t[0] != OP_END);
            _.commitBytes();
            let i = _.readVarUint32(),
                r = [];
            for (let e = 0; e < i; e++) {
                const e = _.readVarUint32(),
                    t = this._getAdjustedFunctionIndex(e);
                r.push(t)
            }
            for (let t = 0; t < o.length; t++) {
                const n = o[t];
                e == n.index && void 0 !== n.elems && (i = (r = n.elems).length)
            }
            _.copyBuffer(VarUint32ToArray(i));
            for (let e = 0; e < i; e++) _.copyBuffer(VarUint32ToArray(r[e]))
        }
        let s = i;
        for (let e = 0; e < a.length; e++, s++) {
            const t = a[e],
                i = t.index;
            if (0 != i) throw new Error("Unsupported element index " + i);
            const r = t.offset,
                n = this._expandArrayVariables(t.elems),
                o = n.length;
            _.copyBuffer(VarUint32ToArray(i)), _.copyBuffer(r), _.copyBuffer(VarUint32ToArray(o)), _.copyBuffer(n)
        }
        const c = _.write(),
            l = VarUint32ToArray(s),
            O = VarUint32ToArray(l.length + c.length);
        this.copyBuffer(O), this.copyBuffer(l), this.copyBuffer(c)
    }
    _addCodeSection() {
        const e = new BufferReader,
            t = this._sectionOptions[SECTION_CODE].newEntries,
            i = VarUint32ToArray(t.length);
        e.copyBuffer(i);
        const r = e.write(),
            n = VarUint32ToArray(r.length);
        this.copyBuffer([SECTION_CODE]), this.copyBuffer(n), this.copyBuffer(r)
    }
    _parseCodeSection() {
        this.commitBytes();
        const e = this.readVarUint32(),
            t = this.readBytes(e),
            i = new BufferReader(t),
            r = i.readVarUint32(),
            n = this._sectionOptions[SECTION_CODE].newEntries,
            _ = r + n.length;
        i.copyBuffer(VarUint32ToArray(_));
        for (let e = 0; e < r; e++) {
            const t = this._getAdjustedFunctionIndex(this._importFuncCount + e);
            this._readFunction(i, t)
        }
        for (let e = r; e < _; e++) {
            const t = this._funcSectionIndexToFuncTableIndex(e),
                r = new BufferReader;
            let _, a = !1;
            for (let e = 0; e < n.length; e++) {
                let i = (_ = n[e]).index;
                if (i instanceof WailVariable && (i = i.value), i == t) {
                    a = !0;
                    break
                }
            }
            if (!a) throw new Error("No CODE entry found for index " + t);
            let o = _.locals,
                s = _.code;
            r.copyBuffer(VarUint32ToArray(o.length));
            for (let e = 0; e < o.length; e++) {
                const t = o[e];
                r.copyBuffer(VarUint32ToArray(1)), r.copyBuffer(Uint8ToArray(t))
            }
            s = this._expandArrayVariables(s), r.copyBuffer(s);
            const c = r.write(),
                l = VarUint32ToArray(c.length);
            i.copyBuffer(l), i.copyBuffer(c)
        }
        const a = i.write(),
            o = VarUint32ToArray(a.length);
        this.copyBuffer(o), this.copyBuffer(a)
    }
    _addDataSection() {
        const e = new BufferReader,
            t = this._sectionOptions[SECTION_DATA].newEntries,
            i = VarUint32ToArray(t.length);
        e.copyBuffer(i);
        for (let i = 0; i < t.length; i++) {
            const r = t[i];
            let n;
            n = void 0 !== r.index ? VarUint32ToArray(r.index) : VarUint32ToArray(0);
            const _ = r.offset;
            _[_.length - 1] != OP_END && _.push(OP_END);
            const a = r.data,
                o = VarUint32ToArray(a.length);
            e.copyBuffer(n), e.copyBuffer(_), e.copyBuffer(o), e.copyBuffer(a)
        }
        const r = e.write(),
            n = VarUint32ToArray(r.length);
        this.copyBuffer([SECTION_DATA]), this.copyBuffer(n), this.copyBuffer(r)
    }
    _parseDataSection() {
        this.commitBytes();
        const e = this.readVarUint32(),
            t = this.inPos,
            i = this.readVarUint32(),
            r = this.inPos - t,
            n = this.readBytes(e - r),
            _ = new BufferReader(n),
            a = this._sectionOptions[SECTION_DATA].newEntries,
            o = this._sectionOptions[SECTION_DATA].existingEntries,
            s = i + a.length;
        _.copyBuffer(VarUint32ToArray(s));
        for (let e = 0; e < i; e++) {
            let t;
            do {
                t = this._readInstruction(_)
            } while (t[0] !== OP_END);
            _.commitBytes();
            let i = _.readVarUint32(),
                r = _.readBytes(i);
            for (let t = 0; t < o.length; t++) {
                const n = o[t];
                e == n.index && void 0 !== n.data && (i = (r = n.data).length)
            }
            _.copyBuffer(VarUint32ToArray(i)), _.copyBuffer(r)
        }
        for (let e = 0; e < a.length; e++) {
            const t = a[e];
            let i;
            i = void 0 !== t.index ? VarUint32ToArray(t.index) : VarUint32ToArray(0);
            const r = t.offset;
            r[r.length - 1] != OP_END && r.push(OP_END);
            const n = t.data,
                o = VarUint32ToArray(n.length);
            _.copyBuffer(i), _.copyBuffer(r), _.copyBuffer(o), _.copyBuffer(n)
        }
        const c = _.write(),
            l = VarUint32ToArray(c.length);
        this.copyBuffer(l), this.copyBuffer(c)
    }
    _readFunction(e, t) {
        const i = this._sectionOptions[SECTION_CODE].existingEntries,
            r = e.readVarUint32(),
            n = e.readBytes(r),
            _ = new BufferReader(n),
            a = _.readVarUint32();
        for (let e = 0; e < a; e++) _.readVarUint32(), _.readUint8();
        _.commitBytes();
        const o = new BufferReader(n.subarray(_.inPos));
        for (; o.inPos < o.inBuffer.length;) this._readInstruction(o), o.commitBytes();
        let s = _.write(),
            c = o.write();
        if ("function" == typeof this._globalFunctionCallback) {
            const e = {};
            e.bytes = o.write(), e.index = t;
            const i = this._globalFunctionCallback(e);
            !1 !== i && (c = i)
        } else
            for (let e = 0; e < this._functionCallbacks.length; e++) {
                const i = this._functionCallbacks[e];
                let r = i.index;
                if (r instanceof WailVariable && (r = r.value), r === t) {
                    const e = {};
                    e.bytes = o.write(), e.index = t;
                    const r = i.callback(e);
                    !1 !== r && (c = r)
                }
            }
        for (let e = 0; e < i.length; e++) {
            const r = i[e];
            let n = r.index;
            if (n instanceof WailVariable && (n = n.value), t == n) {
                const e = new BufferReader,
                    t = r.locals;
                e.copyBuffer(VarUint32ToArray(t.length));
                for (let i = 0; i < t.length; i++) {
                    const r = t[i];
                    e.copyBuffer(VarUint32ToArray(1)), e.copyBuffer(Uint8ToArray(r))
                }
                const i = this._expandArrayVariables(r.code);
                e.copyBuffer(i), c = e.write()
            }
        }
        let l = VarUint32ToArray(s.length + c.length);
        e.copyBuffer(l), e.copyBuffer(s), e.copyBuffer(c)
    }
    _readInstruction(e) {
        e.commitBytes(), e.setAnchor();
        const t = e.readUint8();
        let i, r, n;
        switch (t) {
            case OP_UNREACHABLE:
            case OP_NOP:
            case OP_ELSE:
            case OP_END:
            case OP_RETURN:
            case OP_DROP:
            case OP_SELECT:
            case OP_I32_EQZ:
            case OP_I32_EQ:
            case OP_I32_NE:
            case OP_I32_LT_S:
            case OP_I32_LT_U:
            case OP_I32_GT_S:
            case OP_I32_GT_U:
            case OP_I32_LE_S:
            case OP_I32_LE_U:
            case OP_I32_GE_S:
            case OP_I32_GE_U:
            case OP_I64_EQZ:
            case OP_I64_EQ:
            case OP_I64_NE:
            case OP_I64_LT_S:
            case OP_I64_LT_U:
            case OP_I64_GT_S:
            case OP_I64_GT_U:
            case OP_I64_LE_S:
            case OP_I64_LE_U:
            case OP_I64_GE_S:
            case OP_I64_GE_U:
            case OP_F32_EQ:
            case OP_F32_NE:
            case OP_F32_LT:
            case OP_F32_GT:
            case OP_F32_LE:
            case OP_F32_GE:
            case OP_F64_EQ:
            case OP_F64_NE:
            case OP_F64_LT:
            case OP_F64_GT:
            case OP_F64_LE:
            case OP_F64_GE:
            case OP_I32_CLZ:
            case OP_I32_CTZ:
            case OP_I32_POPCNT:
            case OP_I32_ADD:
            case OP_I32_SUB:
            case OP_I32_MUL:
            case OP_I32_DIV_S:
            case OP_I32_DIV_U:
            case OP_I32_REM_S:
            case OP_I32_REM_U:
            case OP_I32_AND:
            case OP_I32_OR:
            case OP_I32_XOR:
            case OP_I32_SHL:
            case OP_I32_SHR_S:
            case OP_I32_SHR_U:
            case OP_I32_ROTL:
            case OP_I32_ROTR:
            case OP_I64_CLZ:
            case OP_I64_CTZ:
            case OP_I64_POPCNT:
            case OP_I64_ADD:
            case OP_I64_SUB:
            case OP_I64_MUL:
            case OP_I64_DIV_S:
            case OP_I64_DIV_U:
            case OP_I64_REM_S:
            case OP_I64_REM_U:
            case OP_I64_AND:
            case OP_I64_OR:
            case OP_I64_XOR:
            case OP_I64_SHL:
            case OP_I64_SHR_S:
            case OP_I64_SHR_U:
            case OP_I64_ROTL:
            case OP_I64_ROTR:
            case OP_F32_ABS:
            case OP_F32_NEG:
            case OP_F32_CEIL:
            case OP_F32_FLOOR:
            case OP_F32_TRUNC:
            case OP_F32_NEAREST:
            case OP_F32_SQRT:
            case OP_F32_ADD:
            case OP_F32_SUB:
            case OP_F32_MUL:
            case OP_F32_DIV:
            case OP_F32_MIN:
            case OP_F32_MAX:
            case OP_F32_COPYSIGN:
            case OP_F64_ABS:
            case OP_F64_NEG:
            case OP_F64_CEIL:
            case OP_F64_FLOOR:
            case OP_F64_TRUNC:
            case OP_F64_NEAREST:
            case OP_F64_SQRT:
            case OP_F64_ADD:
            case OP_F64_SUB:
            case OP_F64_MUL:
            case OP_F64_DIV:
            case OP_F64_MIN:
            case OP_F64_MAX:
            case OP_F64_COPYSIGN:
            case OP_I32_WRAP_I64:
            case OP_I32_TRUNC_S_F32:
            case OP_I32_TRUNC_U_F32:
            case OP_I32_TRUNC_S_F64:
            case OP_I32_TRUNC_U_F64:
            case OP_I64_EXTEND_S_I32:
            case OP_I64_EXTEND_U_I32:
            case OP_I64_TRUNC_S_F32:
            case OP_I64_TRUNC_U_F32:
            case OP_I64_TRUNC_S_F64:
            case OP_I64_TRUNC_U_F64:
            case OP_F32_CONVERT_S_I32:
            case OP_F32_CONVERT_U_I32:
            case OP_F32_CONVERT_S_I64:
            case OP_F32_CONVERT_U_I64:
            case OP_F32_DEMOTE_F64:
            case OP_F64_CONVERT_S_I32:
            case OP_F64_CONVERT_U_I32:
            case OP_F64_CONVERT_S_I64:
            case OP_F64_CONVERT_U_I64:
            case OP_F64_PROMOTE_F32:
            case OP_I32_REINTERPRET_F32:
            case OP_I64_REINTERPRET_F64:
            case OP_F32_REINTERPRET_I32:
            case OP_F64_REINTERPRET_I64:
                break;
            case OP_BLOCK:
            case OP_LOOP:
            case OP_IF:
            case OP_MEMORY_SIZE:
            case OP_MEMORY_GROW:
                e.readUint8();
                break;
            case OP_BR:
            case OP_BR_IF:
            case OP_GET_LOCAL:
            case OP_SET_LOCAL:
            case OP_TEE_LOCAL:
            case OP_I32_CONST:
            case OP_I64_CONST:
                e.readVarUint32();
                break;
            case OP_GET_GLOBAL:
            case OP_SET_GLOBAL:
                e.commitBytes(), i = e.readVarUint32(), r = this._getAdjustedGlobalIndex(i), e.copyBuffer(VarUint32ToArray(r));
                break;
            case OP_F32_CONST:
                e.readBytes(4);
                break;
            case OP_F64_CONST:
                e.readBytes(8);
                break;
            case OP_I32_LOAD:
            case OP_I64_LOAD:
            case OP_F32_LOAD:
            case OP_F64_LOAD:
            case OP_I32_LOAD8_S:
            case OP_I32_LOAD8_U:
            case OP_I32_LOAD16_S:
            case OP_I32_LOAD16_U:
            case OP_I64_LOAD8_S:
            case OP_I64_LOAD8_U:
            case OP_I64_LOAD16_S:
            case OP_I64_LOAD16_U:
            case OP_I64_LOAD32_S:
            case OP_I64_LOAD32_U:
            case OP_I32_STORE:
            case OP_I64_STORE:
            case OP_F32_STORE:
            case OP_F64_STORE:
            case OP_I32_STORE8:
            case OP_I32_STORE16:
            case OP_I64_STORE8:
            case OP_I64_STORE16:
            case OP_I64_STORE32:
                e.readVarUint32(), e.readVarUint32();
                break;
            case OP_BR_TABLE:
                const _ = e.readVarUint32();
                for (let t = 0; t < _; t++) e.readVarUint32();
                e.readVarUint32();
                break;
            case OP_CALL:
                e.commitBytes(), i = e.readVarUint32(), r = this._getAdjustedFunctionIndex(i), e.copyBuffer(VarUint32ToArray(r));
                break;
            case OP_CALL_INDIRECT:
                e.readVarUint32(), e.readUint8();
                break;
            case OP_I32_EXTEND8_S:
            case OP_I32_EXTEND16_S:
            case OP_I64_EXTEND8_S:
            case OP_I64_EXTEND16_S:
            case OP_I64_EXTEND32_S:
                break;
            case OP_BULK_MEMORY:
                switch (n = e.readUint8()) {
                    case ARG_MEMORY_INIT:
                    case ARG_TABLE_INIT:
                        e.readVarUint32(), e.readUint8();
                        break;
                    case ARG_DATA_DROP:
                    case ARG_ELEM_DROP:
                        e.readVarUint32();
                        break;
                    case ARG_MEMORY_COPY:
                    case ARG_TABLE_COPY:
                        e.readUint8(), e.readUint8();
                        break;
                    case ARG_MEMORY_FILL:
                        e.readUint8()
                }
                break;
            case OP_ATOMIC:
                if ((n = e.readUint8()) > ARG_I64_ATOMIC_RMW_CMPXCHG_32U || n > 2 && n < 16) throw new Error("Unknown argument '" + n + "' for OP_ATOMIC. Probably parsing incorrectly");
                e.readVarUint32(), e.readVarUint32();
                break;
            default:
                throw new Error("Unknown opcode '" + t + "'. Probably parsing incorrectly")
        }
        if (e.commitBytes(), void 0 !== this._instructionCallbacks[t]) {
            const i = e.readFromAnchor(),
                r = this._instructionCallbacks[t](i);
            e.writeAtAnchor(r)
        } else if ("function" == typeof this._globalInstructionCallback) {
            const i = e.readFromAnchor(),
                r = this._globalInstructionCallback[t](i);
            e.writeAtAnchor(r)
        }
        return e.readFromAnchor()
    }
    _funcSectionIndexToFuncTableIndex(e) {
        return e + this._importFuncCount + this._importFuncNewCount
    }
    _getAdjustedFunctionIndex(e) {
        return e >= this._importFuncCount ? e + this._importFuncNewCount : e
    }
    _getAdjustedGlobalIndex(e) {
        return e >= this._importGlobalCount ? e + this._importGlobalNewCount : e
    }
}