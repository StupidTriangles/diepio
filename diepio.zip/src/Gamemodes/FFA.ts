import ArenaEntity from "../Native/Arena";

/**
 * FFA Gamemode Arena
 */
export default class FFAArena extends ArenaEntity {}