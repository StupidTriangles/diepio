import Vector, { VectorAbstract } from "./Vector";

export default class Velocity extends Vector {
    private previousPosition = new Vector();
    public position = new Vector();
    private firstTime = true;

    public updateVelocity() {
        this.x = this.position.x - this.previousPosition.x;
        this.y = this.position.y - this.previousPosition.y;
    }

    public setPosition(newPosition: VectorAbstract) {
        this.previousPosition.set(this.position);
        this.position.set(newPosition);
        if (this.firstTime) {
            this.previousPosition.set(newPosition);
            this.firstTime = false;
        }
        this.updateVelocity();
    }
}
