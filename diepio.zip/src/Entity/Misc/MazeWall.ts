import GameServer from "../../Game";
import ObjectEntity from "../Object";

import { PhysicsFlags, Color } from "../../Const/Enums";
/**
 * Only used for maze walls and nothing else.
 */
export default class MazeWall extends ObjectEntity {
    public constructor(game: GameServer, x: number, y: number, width: number, height: number) {
        super(game);

        this.positionData.values.x = x;
        this.positionData.values.y = y;

        this.physicsData.values.width = width;
        this.physicsData.values.size = height;
        this.physicsData.values.sides = 2;
        this.physicsData.values.flags |= PhysicsFlags.isSolidWall | PhysicsFlags.showsOnMap;
        this.physicsData.values.pushFactor = 2;
        this.physicsData.values.absorbtionFactor = 0;

        this.styleData.values.borderWidth = 10;
        this.styleData.values.color = Color.Box;
    }
}
