// Hi there

// TODO:
// Implement 8 drones owned by an invisible overlord