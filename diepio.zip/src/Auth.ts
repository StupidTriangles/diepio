import { IncomingMessage, ServerResponse } from "http";

import { AccessLevel } from "./config";

interface DiscordAuthInterface {
    interactionsKey: string;
    buildHash(id: string, perm: AccessLevel): string;
    verifyCode(code: string): boolean;
    handleInteraction(req: IncomingMessage, res: ServerResponse): void;
}

const authenticator: DiscordAuthInterface | null = null;

export default authenticator;